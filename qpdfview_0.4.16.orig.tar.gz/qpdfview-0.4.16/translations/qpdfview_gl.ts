<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>Model::ImageDocument</name>
    <message>
        <location filename="../sources/imagemodel.cpp" line="126"/>
        <source>Image (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/imagemodel.cpp" line="154"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/imagemodel.cpp" line="155"/>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/imagemodel.cpp" line="156"/>
        <source>Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/imagemodel.cpp" line="164"/>
        <location filename="../sources/imagemodel.cpp" line="167"/>
        <location filename="../sources/imagemodel.cpp" line="170"/>
        <location filename="../sources/imagemodel.cpp" line="173"/>
        <location filename="../sources/imagemodel.cpp" line="178"/>
        <location filename="../sources/imagemodel.cpp" line="182"/>
        <source>Format</source>
        <translation type="unfinished">Formato</translation>
    </message>
    <message>
        <location filename="../sources/imagemodel.cpp" line="164"/>
        <source>Monochrome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/imagemodel.cpp" line="167"/>
        <source>Indexed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/imagemodel.cpp" line="170"/>
        <source>32 bits RGB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/imagemodel.cpp" line="173"/>
        <source>32 bits ARGB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/imagemodel.cpp" line="178"/>
        <source>16 bits RGB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/imagemodel.cpp" line="182"/>
        <source>24 bits RGB</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Model::PdfDocument</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="913"/>
        <source>Linearized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="927"/>
        <source>Name</source>
        <translation type="unfinished">Nome</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="927"/>
        <source>Type</source>
        <translation type="unfinished">Tipo</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="927"/>
        <source>Embedded</source>
        <translation type="unfinished">Encaixado</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="927"/>
        <source>Subset</source>
        <translation type="unfinished">Subconxunto</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="927"/>
        <source>File</source>
        <translation type="unfinished">Ficheiro</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="912"/>
        <location filename="../sources/pdfmodel.cpp" line="913"/>
        <location filename="../sources/pdfmodel.cpp" line="935"/>
        <location filename="../sources/pdfmodel.cpp" line="936"/>
        <source>Yes</source>
        <translation type="unfinished">Si</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="910"/>
        <source>PDF version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="912"/>
        <source>Encrypted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="912"/>
        <location filename="../sources/pdfmodel.cpp" line="913"/>
        <location filename="../sources/pdfmodel.cpp" line="935"/>
        <location filename="../sources/pdfmodel.cpp" line="936"/>
        <source>No</source>
        <translation type="unfinished">Non</translation>
    </message>
</context>
<context>
    <name>Model::PdfPage</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="599"/>
        <source>Information</source>
        <translation type="unfinished">Información</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="599"/>
        <source>Version 0.20.1 or higher of the Poppler library is required to add or remove annotations.</source>
        <translation type="unfinished">Precísase a version 0.20.1 ou superior da biblioteca Poppler para engadir ou eliminar anotacións.</translation>
    </message>
</context>
<context>
    <name>Model::PsDocument</name>
    <message>
        <location filename="../sources/psmodel.cpp" line="241"/>
        <source>Title</source>
        <translation type="unfinished">Título</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="242"/>
        <source>Created for</source>
        <translation type="unfinished">Creado para</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="243"/>
        <source>Creator</source>
        <translation type="unfinished">Creador</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="244"/>
        <source>Creation date</source>
        <translation type="unfinished">Data de creación</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="245"/>
        <source>Format</source>
        <translation type="unfinished">Formato</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="246"/>
        <source>Language level</source>
        <translation type="unfinished">Nivel de idioma</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../sources/main.cpp" line="152"/>
        <source>An empty instance name is not allowed.</source>
        <translation type="unfinished">Non se permite un nome de instancia baleiro.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="163"/>
        <source>An empty search text is not allowed.</source>
        <translation type="unfinished">Non se permite un texto de busca baleiro.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="191"/>
        <source>Choose instance</source>
        <translation type="unfinished">Seleccionar instancia</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="191"/>
        <source>Instance:</source>
        <translation type="unfinished">Instancia:</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="220"/>
        <source>Unknown command-line option &apos;%1&apos;.</source>
        <translation type="unfinished">Opción de liña de ordes descoñecida «%1».</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="251"/>
        <source>Using &apos;--instance&apos; requires an instance name.</source>
        <translation type="unfinished">O uso de «--instance» require un nome de instancia.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="257"/>
        <source>Using &apos;--instance&apos; is not allowed without using &apos;--unique&apos;.</source>
        <translation type="unfinished">Non se permite o uso de «--instance» sen usar «--unique».</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="263"/>
        <source>An instance name must only contain the characters &quot;[A-Z][a-z][0-9]_&quot; and must not begin with a digit.</source>
        <translation type="unfinished">O nome dunha instancia debe conter só os caracteres «[A-Z][a-z][0-9]_» e non debe comezar cun díxito.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="269"/>
        <source>Using &apos;--search&apos; requires a search text.</source>
        <translation type="unfinished">O uso de «--search» require un texto de busca.</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="347"/>
        <source>SyncTeX data for &apos;%1&apos; could not be found.</source>
        <translation type="unfinished">Non foi posíbel atopar os datos de SyncTeX para «%1».</translation>
    </message>
    <message>
        <location filename="../sources/main.cpp" line="446"/>
        <source>Could not prepare signal handler.</source>
        <translation type="unfinished">Non foi posíbel preparar o xestor de sinais.</translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="832"/>
        <source>Shift</source>
        <translation type="unfinished">Maiús.</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="833"/>
        <source>Ctrl</source>
        <translation type="unfinished">Ctrl</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="834"/>
        <source>Alt</source>
        <translation type="unfinished">Alt</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="835"/>
        <source>Shift and Ctrl</source>
        <translation type="unfinished">Maiús e Ctrl</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="836"/>
        <source>Shift and Alt</source>
        <translation type="unfinished">Maiús e Alt</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="837"/>
        <source>Ctrl and Alt</source>
        <translation type="unfinished">Ctrl e Alt</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="838"/>
        <source>Right mouse button</source>
        <translation type="unfinished">Botón dereito do rato</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="839"/>
        <source>Middle mouse button</source>
        <translation type="unfinished">Botón central do rato</translation>
    </message>
</context>
<context>
    <name>qpdfview::BookmarkDialog</name>
    <message>
        <location filename="../sources/bookmarkdialog.cpp" line="39"/>
        <source>Bookmark</source>
        <translation type="unfinished">Marcador</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkdialog.cpp" line="48"/>
        <source>Page:</source>
        <translation type="unfinished">Páxina:</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkdialog.cpp" line="53"/>
        <source>Label:</source>
        <translation type="unfinished">Etiqueta:</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkdialog.cpp" line="58"/>
        <source>Comment:</source>
        <translation type="unfinished">Comentario:</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkdialog.cpp" line="64"/>
        <source>Modified:</source>
        <translation type="unfinished">Modificado:</translation>
    </message>
</context>
<context>
    <name>qpdfview::BookmarkMenu</name>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="39"/>
        <source>&amp;Open</source>
        <translation type="unfinished">&amp;Abrir</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="44"/>
        <source>Open in new &amp;tab</source>
        <translation type="unfinished">&amp;Abrir nunha nova lapela</translation>
    </message>
    <message>
        <location filename="../sources/bookmarkmenu.cpp" line="54"/>
        <source>&amp;Remove bookmark</source>
        <translation type="unfinished">&amp;Retirar marcador</translation>
    </message>
</context>
<context>
    <name>qpdfview::Database</name>
    <message>
        <location filename="../sources/database.cpp" line="910"/>
        <source>Jump to page %1</source>
        <translation type="unfinished">Ir á páxina %1</translation>
    </message>
</context>
<context>
    <name>qpdfview::DocumentView</name>
    <message>
        <location filename="../sources/documentview.cpp" line="993"/>
        <location filename="../sources/documentview.cpp" line="1620"/>
        <source>Information</source>
        <translation type="unfinished">Información</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="993"/>
        <source>The source editor has not been set.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="1620"/>
        <source>Opening URL is disabled in the settings.</source>
        <translation type="unfinished">A apertura de URL está desactivada nos axustes.</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="2100"/>
        <source>Printing &apos;%1&apos;...</source>
        <translation type="unfinished">Imprimindo «%1»...</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="2174"/>
        <source>Unlock %1</source>
        <translation type="unfinished">Desbloquear %1</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="2174"/>
        <source>Password:</source>
        <translation type="unfinished">Contrasinal:</translation>
    </message>
    <message>
        <location filename="../sources/documentview.cpp" line="2216"/>
        <source>Page %1</source>
        <translation type="unfinished">Páxina %1</translation>
    </message>
</context>
<context>
    <name>qpdfview::FileAttachmentAnnotationWidget</name>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="112"/>
        <source>Save...</source>
        <translation type="unfinished">Gardar...</translation>
    </message>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="113"/>
        <source>Save and open...</source>
        <translation type="unfinished">Gardar e abrir...</translation>
    </message>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="160"/>
        <source>Save file attachment</source>
        <translation type="unfinished">Gardar anexo</translation>
    </message>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="176"/>
        <location filename="../sources/annotationwidgets.cpp" line="182"/>
        <source>Warning</source>
        <translation type="unfinished">Aviso</translation>
    </message>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="176"/>
        <source>Could not open file attachment saved to &apos;%1&apos;.</source>
        <translation type="unfinished">Non foi posíbel abrir o ficheiro do anexo gardado en «%1».</translation>
    </message>
    <message>
        <location filename="../sources/annotationwidgets.cpp" line="182"/>
        <source>Could not save file attachment to &apos;%1&apos;.</source>
        <translation type="unfinished">Non foi posíbel gardar o anexo en «%1».</translation>
    </message>
</context>
<context>
    <name>qpdfview::FontsDialog</name>
    <message>
        <location filename="../sources/fontsdialog.cpp" line="37"/>
        <source>Fonts</source>
        <translation type="unfinished">Tipos de letra</translation>
    </message>
</context>
<context>
    <name>qpdfview::HelpDialog</name>
    <message>
        <location filename="../sources/helpdialog.cpp" line="40"/>
        <source>Help</source>
        <translation type="unfinished">Axuda</translation>
    </message>
    <message>
        <location filename="../sources/helpdialog.cpp" line="47"/>
        <source>help.html</source>
        <extracomment>Please replace by file name of localized help if available, e.g. &quot;help_fr.html&quot;.</extracomment>
        <translation type="unfinished">help.html</translation>
    </message>
    <message>
        <location filename="../sources/helpdialog.cpp" line="62"/>
        <source>Find previous</source>
        <translation type="unfinished">Buscar anterior</translation>
    </message>
    <message>
        <location filename="../sources/helpdialog.cpp" line="66"/>
        <source>Find next</source>
        <translation type="unfinished">Buscar seguinte</translation>
    </message>
</context>
<context>
    <name>qpdfview::MainWindow</name>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2894"/>
        <source>Toggle tool bars</source>
        <translation type="unfinished">Alternar barra de ferramentas</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2895"/>
        <source>Toggle menu bar</source>
        <translation type="unfinished">Alternar barra do menú</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="362"/>
        <location filename="../sources/mainwindow.cpp" line="445"/>
        <location filename="../sources/mainwindow.cpp" line="1202"/>
        <location filename="../sources/mainwindow.cpp" line="1219"/>
        <location filename="../sources/mainwindow.cpp" line="1236"/>
        <location filename="../sources/mainwindow.cpp" line="1274"/>
        <location filename="../sources/mainwindow.cpp" line="1417"/>
        <location filename="../sources/mainwindow.cpp" line="2501"/>
        <location filename="../sources/mainwindow.cpp" line="2515"/>
        <source>Warning</source>
        <translation type="unfinished">Aviso</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="362"/>
        <location filename="../sources/mainwindow.cpp" line="445"/>
        <source>Could not open &apos;%1&apos;.</source>
        <translation type="unfinished">Non foi posíbel abrir «%1».</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="672"/>
        <source>Copy file path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="673"/>
        <source>Select file path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="675"/>
        <source>Close all tabs</source>
        <translation type="unfinished">Pechar todas as lapelas</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="676"/>
        <source>Close all tabs but this one</source>
        <translation type="unfinished">Pechar todas as lapelas excepto este</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="677"/>
        <source>Close all tabs to the left</source>
        <translation type="unfinished">Pechar todas as lapelas á esquerda</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="678"/>
        <source>Close all tabs to the right</source>
        <translation type="unfinished">Pechar todas as lapelas á dereita</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1157"/>
        <source>Open</source>
        <translation type="unfinished">Abrir</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1173"/>
        <source>Open in new tab</source>
        <translation type="unfinished">Abrir nunha nova lapela</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1202"/>
        <location filename="../sources/mainwindow.cpp" line="1417"/>
        <source>Could not refresh &apos;%1&apos;.</source>
        <translation type="unfinished">Non foi posíbel actualizar «%1».</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1209"/>
        <source>Save copy</source>
        <translation type="unfinished">Gardar unha copia</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1219"/>
        <source>Could not save copy at &apos;%1&apos;.</source>
        <translation type="unfinished">Non foi posíbel gardar unha copia en «%1».</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1226"/>
        <location filename="../sources/mainwindow.cpp" line="2505"/>
        <source>Save as</source>
        <translation type="unfinished">Gardar como</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1236"/>
        <location filename="../sources/mainwindow.cpp" line="2515"/>
        <source>Could not save as &apos;%1&apos;.</source>
        <translation type="unfinished">Non foi posíbel gardalo como «%1».</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1274"/>
        <source>Could not print &apos;%1&apos;.</source>
        <translation type="unfinished">Non foi posíbel imprimir «%1».</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1310"/>
        <source>Set first page</source>
        <translation type="unfinished">Estabelecer a primeira páxina</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1310"/>
        <source>Select the first page of the body matter:</source>
        <translation type="unfinished">Seleccionar a primeira páxina do corpo principal:</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1323"/>
        <source>Jump to page</source>
        <translation type="unfinished">Ir á páxina</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1323"/>
        <source>Page:</source>
        <translation type="unfinished">Páxina:</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1724"/>
        <source>Jump to page %1</source>
        <translation type="unfinished">Ir á páxina %1</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1875"/>
        <source>About qpdfview</source>
        <translation type="unfinished">Sobre qpdfview</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1875"/>
        <source>&lt;p&gt;&lt;b&gt;qpdfview %1&lt;/b&gt;&lt;/p&gt;&lt;p&gt;qpdfview is a tabbed document viewer using Qt.&lt;/p&gt;&lt;p&gt;This version includes:&lt;ul&gt;</source>
        <translation type="unfinished">&lt;p&gt;&lt;b&gt;qpdfview %1&lt;/b&gt;&lt;/p&gt;&lt;p&gt;qpdfview é un visor de documentos provisto de lapelas e que usa QT.&lt;/p&gt;&lt;p&gt;Esta versión inclúe:&lt;ul&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1879"/>
        <source>&lt;li&gt;PDF support using Poppler %1&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;Compatibilidade PDF usando Poppler %1&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1882"/>
        <source>&lt;li&gt;PS support using libspectre %1&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;Compatibilidade PS usando libspectre %1&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1885"/>
        <source>&lt;li&gt;DjVu support using DjVuLibre %1&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;Compatibilidade DjVu usando DjVuLibre %1&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1888"/>
        <source>&lt;li&gt;PDF support using Fitz %1&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;Compatibilidade PDF usando Fitz %1&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1891"/>
        <source>&lt;li&gt;Printing support using CUPS %1&lt;/li&gt;</source>
        <translation type="unfinished">&lt;li&gt;Compatibilidade coa impresión usando CUPS %1&lt;/li&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="1893"/>
        <source>&lt;/ul&gt;&lt;p&gt;See &lt;a href=&quot;https://launchpad.net/qpdfview&quot;&gt;launchpad.net/qpdfview&lt;/a&gt; for more information.&lt;/p&gt;&lt;p&gt;&amp;copy; 2012-2015 The qpdfview developers&lt;/p&gt;</source>
        <translation type="unfinished">&lt;/ul&gt;&lt;p&gt;Ver &lt;a href=&quot;https://launchpad.net/qpdfview&quot;&gt;launchpad.net/qpdfview&lt;/a&gt; para máis información.&lt;/p&gt;&lt;p&gt;&amp;copy; 2012-2015 Os desenvolvedores de qpdfview&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2178"/>
        <location filename="../sources/mainwindow.cpp" line="2884"/>
        <source>&amp;Remove bookmark</source>
        <translation type="unfinished">&amp;Retirar marcador</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2179"/>
        <source>&amp;Edit bookmark</source>
        <translation type="unfinished">&amp;Editar o marcador</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2501"/>
        <source>The document &apos;%1&apos; has been modified. Do you want to save your changes?</source>
        <translation type="unfinished">O documento «%1» modificouse. Desexa gardar os cambios?</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2608"/>
        <source>Edit &apos;%1&apos; at %2,%3...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2707"/>
        <source>Page width</source>
        <translation type="unfinished">Largo da páxina</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2708"/>
        <source>Page size</source>
        <translation type="unfinished">Tamaño da páxina</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2731"/>
        <source>Match &amp;case</source>
        <translation type="unfinished">Distinguir &amp;maiúsculas</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2732"/>
        <source>Whole &amp;words</source>
        <translation type="unfinished">&amp;Palabras completas</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2733"/>
        <source>Highlight &amp;all</source>
        <translation type="unfinished">Destacar &amp;todos</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2795"/>
        <source>&amp;Open...</source>
        <translation type="unfinished">&amp;Abrir...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2796"/>
        <source>Open in new &amp;tab...</source>
        <translation type="unfinished">Abrir nunha nova &amp;lapela...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2797"/>
        <source>Open &amp;copy in new tab</source>
        <translation type="unfinished">Abrir e &amp;copiar nunha nova lapela</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2798"/>
        <source>Open containing &amp;folder</source>
        <translation type="unfinished">Abrir o cart&amp;fol que o contén</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2799"/>
        <source>&amp;Refresh</source>
        <translation type="unfinished">&amp;Actualizar</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2800"/>
        <source>&amp;Save copy...</source>
        <translation type="unfinished">&amp;Gardar unha copia...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2801"/>
        <source>Save &amp;as...</source>
        <translation type="unfinished">Gardar &amp;como...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2802"/>
        <source>&amp;Print...</source>
        <translation type="unfinished">&amp;Imprimir...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2803"/>
        <source>E&amp;xit</source>
        <translation type="unfinished">&amp;Saír</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2807"/>
        <source>&amp;Previous page</source>
        <translation type="unfinished">Páxina &amp;anterior</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2808"/>
        <source>&amp;Next page</source>
        <translation type="unfinished">Páxina &amp;seguinte</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2809"/>
        <source>&amp;First page</source>
        <translation type="unfinished">&amp;Primeira páxina</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2810"/>
        <source>&amp;Last page</source>
        <translation type="unfinished">&amp;Última páxina</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2812"/>
        <source>&amp;Set first page...</source>
        <translation type="unfinished">E&amp;stabelecer a primeira páxina...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2814"/>
        <source>&amp;Jump to page...</source>
        <translation type="unfinished">&amp;Ir á páxina...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2816"/>
        <source>Jump &amp;backward</source>
        <translation type="unfinished">Ir cara a a&amp;trás</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2817"/>
        <source>Jump for&amp;ward</source>
        <translation type="unfinished">Ir cara a a&amp;diante</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2819"/>
        <source>&amp;Search...</source>
        <translation type="unfinished">&amp;Buscar...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2820"/>
        <source>Find previous</source>
        <translation type="unfinished">Buscar anterior</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2821"/>
        <source>Find next</source>
        <translation type="unfinished">Buscar seguinte</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2822"/>
        <source>Cancel search</source>
        <translation type="unfinished">Cancelar busca</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2824"/>
        <source>&amp;Copy to clipboard</source>
        <translation type="unfinished">&amp;Copiar ao portapapeis</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2825"/>
        <source>&amp;Add annotation</source>
        <translation type="unfinished">&amp;Engadir anotación</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2827"/>
        <source>Settings...</source>
        <translation type="unfinished">Axustes...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2831"/>
        <source>&amp;Continuous</source>
        <translation type="unfinished">&amp;Contínuo</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2832"/>
        <source>&amp;Two pages</source>
        <translation type="unfinished">&amp;Dúas páxinas</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2833"/>
        <source>Two pages &amp;with cover page</source>
        <translation type="unfinished">Dúas páxinas &amp;con portada</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2834"/>
        <source>&amp;Multiple pages</source>
        <translation type="unfinished">&amp;Múltiples páxinas</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2836"/>
        <source>Right to left</source>
        <translation type="unfinished">De dereita a esquerda</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2838"/>
        <source>Zoom &amp;in</source>
        <translation type="unfinished">&amp;Ampliar</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2839"/>
        <source>Zoom &amp;out</source>
        <translation type="unfinished">&amp;Reducir</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2840"/>
        <source>Original &amp;size</source>
        <translation type="unfinished">&amp;Tamaño orixinal</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2842"/>
        <source>Fit to page width</source>
        <translation type="unfinished">Axustar á largura da páxina</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2843"/>
        <source>Fit to page size</source>
        <translation type="unfinished">Axustar ao tamaño da páxina</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2845"/>
        <source>Rotate &amp;left</source>
        <translation type="unfinished">Rotar á &amp;esquerda</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2846"/>
        <source>Rotate &amp;right</source>
        <translation type="unfinished">Rotar á &amp;dereita</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2848"/>
        <source>Invert colors</source>
        <translation type="unfinished">Inverter as cores</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2849"/>
        <source>Convert to grayscale</source>
        <translation type="unfinished">Converter a escala de grisis</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2850"/>
        <source>Trim margins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2852"/>
        <source>Darken with paper color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2853"/>
        <source>Lighten with paper color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2855"/>
        <source>Fonts...</source>
        <translation type="unfinished">Tipos de letra...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2857"/>
        <source>&amp;Fullscreen</source>
        <translation type="unfinished">&amp;Pantalla completa</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2858"/>
        <source>&amp;Presentation...</source>
        <translation type="unfinished">&amp;Presentación...</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2862"/>
        <source>&amp;Previous tab</source>
        <translation type="unfinished">Lapela &amp;anterior</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2863"/>
        <source>&amp;Next tab</source>
        <translation type="unfinished">Lapela &amp;seguinte</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2865"/>
        <source>&amp;Close tab</source>
        <translation type="unfinished">&amp;Pechar a lapela</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2866"/>
        <source>Close &amp;all tabs</source>
        <translation type="unfinished">Pechar &amp;todas as lapelas</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2867"/>
        <source>Close all tabs &amp;but current tab</source>
        <translation type="unfinished">Pechar todas as lapelas &amp;agás a actual</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2869"/>
        <source>Restore &amp;most recently closed tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2880"/>
        <source>&amp;Previous bookmark</source>
        <translation type="unfinished">Marcador &amp;anterior</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2881"/>
        <source>&amp;Next bookmark</source>
        <translation type="unfinished">Marcador &amp;seguinte</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2883"/>
        <source>&amp;Add bookmark</source>
        <translation type="unfinished">&amp;Engadir marcador</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2885"/>
        <source>Remove all bookmarks</source>
        <translation type="unfinished">Retirar todos os marcadores</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2889"/>
        <source>&amp;Contents</source>
        <translation type="unfinished">&amp;Contidos</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2890"/>
        <source>&amp;About</source>
        <translation type="unfinished">&amp;Sobre</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2918"/>
        <location filename="../sources/mainwindow.cpp" line="3121"/>
        <source>&amp;File</source>
        <translation type="unfinished">&amp;Ficheiro</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2921"/>
        <location filename="../sources/mainwindow.cpp" line="3142"/>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;Editar</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2924"/>
        <location filename="../sources/mainwindow.cpp" line="3155"/>
        <source>&amp;View</source>
        <translation type="unfinished">&amp;Ver</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="2959"/>
        <source>&amp;Search</source>
        <translation type="unfinished">&amp;Buscar</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="3047"/>
        <source>&amp;Outline</source>
        <translation type="unfinished">&amp;Esquema</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="3066"/>
        <source>&amp;Properties</source>
        <translation type="unfinished">&amp;Propiedades</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="3080"/>
        <source>Thumb&amp;nails</source>
        <translation type="unfinished">Mi&amp;niaturas</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="3094"/>
        <source>Book&amp;marks</source>
        <translation type="unfinished">&amp;Marcadores</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="3166"/>
        <source>Composition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="3172"/>
        <source>&amp;Tool bars</source>
        <translation type="unfinished">&amp;Barras de ferramentas</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="3175"/>
        <source>&amp;Docks</source>
        <translation type="unfinished">&amp;Docas</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="3189"/>
        <source>&amp;Tabs</source>
        <translation type="unfinished">&amp;Lapelas</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="3212"/>
        <source>&amp;Bookmarks</source>
        <translation type="unfinished">&amp;Marcadores</translation>
    </message>
    <message>
        <location filename="../sources/mainwindow.cpp" line="3223"/>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;Axuda</translation>
    </message>
</context>
<context>
    <name>qpdfview::PageItem</name>
    <message>
        <location filename="../sources/pageitem.cpp" line="362"/>
        <source>Go to page %1.</source>
        <translation type="unfinished">Ir á páxina %1.</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="366"/>
        <source>Go to page %1 of file &apos;%2&apos;.</source>
        <translation type="unfinished">Ir á páxina %1 do ficheiro «%2».</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="374"/>
        <source>Open &apos;%1&apos;.</source>
        <translation type="unfinished">Abrir «%1».</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="409"/>
        <source>Edit form field &apos;%1&apos;.</source>
        <translation type="unfinished">Editar campo do formulario «%1».</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="728"/>
        <source>Copy &amp;text</source>
        <translation type="unfinished">&amp;Copiar texto</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="729"/>
        <source>&amp;Select text</source>
        <translation type="unfinished">&amp;Seleccionar o texto</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="730"/>
        <source>Copy &amp;image</source>
        <translation type="unfinished">Copiar &amp;imaxe</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="731"/>
        <source>Save image to &amp;file...</source>
        <translation type="unfinished">Gardar a imaxe nun &amp;ficheiro...</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="766"/>
        <source>Save image to file</source>
        <translation type="unfinished">Gardar a imaxe nun ficheiro</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="770"/>
        <source>Warning</source>
        <translation type="unfinished">Aviso</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="770"/>
        <source>Could not save image to file &apos;%1&apos;.</source>
        <translation type="unfinished">Non foi posíbel gardar a imaxe no ficheiro «%1».</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="783"/>
        <source>Add &amp;text</source>
        <translation type="unfinished">Engadir &amp;texto</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="784"/>
        <source>Add &amp;highlight</source>
        <translation type="unfinished">Engadir &amp;resalte</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="823"/>
        <source>&amp;Copy link address</source>
        <translation type="unfinished">&amp;Copiar o enderezo da ligazón</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="824"/>
        <source>&amp;Select link address</source>
        <translation type="unfinished">&amp;Seleccionar o enderezo da ligazón</translation>
    </message>
    <message>
        <location filename="../sources/pageitem.cpp" line="847"/>
        <source>&amp;Remove annotation</source>
        <translation type="unfinished">&amp;Retirar a anotación</translation>
    </message>
</context>
<context>
    <name>qpdfview::PdfSettingsWidget</name>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="1007"/>
        <source>Antialiasing:</source>
        <translation type="unfinished">Suavizado:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="1014"/>
        <source>Text antialiasing:</source>
        <translation type="unfinished">Suavizado do texto:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="1021"/>
        <location filename="../sources/pdfmodel.cpp" line="1060"/>
        <source>None</source>
        <translation type="unfinished">Ningún</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="1022"/>
        <source>Full</source>
        <translation type="unfinished">Completo</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="1023"/>
        <source>Reduced</source>
        <translation type="unfinished">Reducido</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="1026"/>
        <location filename="../sources/pdfmodel.cpp" line="1033"/>
        <source>Text hinting:</source>
        <translation type="unfinished">Optimización do texto:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="1042"/>
        <source>Ignore paper color:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="1053"/>
        <source>Overprint preview:</source>
        <translation type="unfinished">Previsualización da sobreimpresión:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="1061"/>
        <source>Solid</source>
        <translation type="unfinished">Sólido</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="1062"/>
        <source>Shaped</source>
        <translation type="unfinished">Con forma</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="1065"/>
        <source>Thin line mode:</source>
        <translation type="unfinished">Modo de liña fina:</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="1070"/>
        <source>Splash</source>
        <translation type="unfinished">Pantalla inicial</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="1071"/>
        <source>Arthur</source>
        <translation type="unfinished">Arthur</translation>
    </message>
    <message>
        <location filename="../sources/pdfmodel.cpp" line="1074"/>
        <source>Backend:</source>
        <translation type="unfinished">Infraestrutura:</translation>
    </message>
</context>
<context>
    <name>qpdfview::PluginHandler</name>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="307"/>
        <source>Image (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="312"/>
        <source>Supported formats (%1)</source>
        <translation type="unfinished">Formatos admitidos (%1)</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="323"/>
        <source>Could not match file type of &apos;%1&apos;!</source>
        <translation type="unfinished">Non foi posíbel atopar un tipo de ficheiro «%1».</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="330"/>
        <source>Critical</source>
        <translation type="unfinished">Crítico</translation>
    </message>
    <message>
        <location filename="../sources/pluginhandler.cpp" line="330"/>
        <source>Could not load plug-in for file type &apos;%1&apos;!</source>
        <translation type="unfinished">Non foi posíbel cargar o engadido para o tipo de ficheiro «%1».</translation>
    </message>
</context>
<context>
    <name>qpdfview::PrintDialog</name>
    <message>
        <location filename="../sources/printdialog.cpp" line="64"/>
        <source>Fit to page:</source>
        <translation type="unfinished">Axustar a páxina:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="68"/>
        <source>Page ranges:</source>
        <translation type="unfinished">Intervalo de páxinas:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="73"/>
        <source>All pages</source>
        <translation type="unfinished">Todas as páxinas</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="74"/>
        <source>Even pages</source>
        <translation type="unfinished">Páxinas pares</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="75"/>
        <source>Odd pages</source>
        <translation type="unfinished">Páxinas impares</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="78"/>
        <source>Page set:</source>
        <translation type="unfinished">Grupo de páxinas:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="81"/>
        <source>Single page</source>
        <translation type="unfinished">Páxina única</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="82"/>
        <source>Two pages</source>
        <translation type="unfinished">Dúas páxinas</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="83"/>
        <source>Four pages</source>
        <translation type="unfinished">Catro páxinas</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="84"/>
        <source>Six pages</source>
        <translation type="unfinished">Seis páxinas</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="85"/>
        <source>Nine pages</source>
        <translation type="unfinished">Nove páxinas</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="86"/>
        <source>Sixteen pages</source>
        <translation type="unfinished">Dezaseis páxinas</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="89"/>
        <source>Number-up:</source>
        <translation type="unfinished">Número de páxinas:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="92"/>
        <source>Bottom to top and left to right</source>
        <translation type="unfinished">De abaixo a arriba e de esquerda a dereita</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="93"/>
        <source>Bottom to top and right to left</source>
        <translation type="unfinished">De abaixo a arriba e de dereita a esquerda</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="94"/>
        <source>Left to right and bottom to top</source>
        <translation type="unfinished">De esquerda a dereita e de abaixo a arriba</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="95"/>
        <source>Left to right and top to bottom</source>
        <translation type="unfinished">De esquerda a dereita e de arriba a abaixo</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="96"/>
        <source>Right to left and bottom to top</source>
        <translation type="unfinished">De dereita a esquerda e de abaixo a arriba</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="97"/>
        <source>Right to left and top to bottom</source>
        <translation type="unfinished">De dereita a esquerda e de arriba a abaixo</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="98"/>
        <source>Top to bottom and left to right</source>
        <translation type="unfinished">De arriba a abaixo e de esquerda a dereita</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="99"/>
        <source>Top to bottom and right to left</source>
        <translation type="unfinished">De arriba a abaixo e de dereita a esquerda</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="102"/>
        <source>Number-up layout:</source>
        <translation type="unfinished">Disposición das páxinas:</translation>
    </message>
    <message>
        <location filename="../sources/printdialog.cpp" line="106"/>
        <source>Extended options</source>
        <translation type="unfinished">Opcións ampliadas</translation>
    </message>
</context>
<context>
    <name>qpdfview::PsSettingsWidget</name>
    <message>
        <location filename="../sources/psmodel.cpp" line="262"/>
        <source>Graphics antialias bits:</source>
        <translation type="unfinished">Bits de suavizado de gráficos:</translation>
    </message>
    <message>
        <location filename="../sources/psmodel.cpp" line="270"/>
        <source>Text antialias bits:</source>
        <translation type="unfinished">Bits de suavizado de texto:</translation>
    </message>
</context>
<context>
    <name>qpdfview::RecentlyClosedMenu</name>
    <message>
        <location filename="../sources/recentlyclosedmenu.cpp" line="32"/>
        <source>&amp;Recently closed</source>
        <translation type="unfinished">Pechados &amp;recentemente</translation>
    </message>
    <message>
        <location filename="../sources/recentlyclosedmenu.cpp" line="39"/>
        <source>&amp;Clear list</source>
        <translation type="unfinished">&amp;Borrar lista</translation>
    </message>
</context>
<context>
    <name>qpdfview::RecentlyUsedMenu</name>
    <message>
        <location filename="../sources/recentlyusedmenu.cpp" line="32"/>
        <source>Recently &amp;used</source>
        <translation type="unfinished">Usados &amp;recentemente</translation>
    </message>
    <message>
        <location filename="../sources/recentlyusedmenu.cpp" line="41"/>
        <source>&amp;Clear list</source>
        <translation type="unfinished">&amp;Limpar lista</translation>
    </message>
</context>
<context>
    <name>qpdfview::SearchModel</name>
    <message>
        <location filename="../sources/searchmodel.cpp" line="148"/>
        <source>&lt;b&gt;%1&lt;/b&gt; occurrences</source>
        <translation type="unfinished">&lt;b&gt;%1&lt;/b&gt; ocorrencias</translation>
    </message>
    <message>
        <location filename="../sources/searchmodel.cpp" line="182"/>
        <source>&lt;b&gt;%1&lt;/b&gt; occurrences on page &lt;b&gt;%2&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;%1&lt;/b&gt; ocorrencias na páxina &lt;b&gt;%2&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>qpdfview::SearchableMenu</name>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="181"/>
        <source>Search for &apos;%1&apos;...</source>
        <translation type="unfinished">Buscar «%1»...</translation>
    </message>
</context>
<context>
    <name>qpdfview::SettingsDialog</name>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="104"/>
        <source>Settings</source>
        <translation type="unfinished">Axustes</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="107"/>
        <source>General</source>
        <translation type="unfinished">Xeral</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="140"/>
        <source>&amp;Behavior</source>
        <translation type="unfinished">&amp;Comportamento</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="141"/>
        <source>&amp;Graphics</source>
        <translation type="unfinished">&amp;Gráficos</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="142"/>
        <source>&amp;Interface</source>
        <translation type="unfinished">&amp;Interface</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="143"/>
        <source>&amp;Shortcuts</source>
        <translation type="unfinished">&amp;Atallos</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="144"/>
        <source>&amp;Modifiers</source>
        <translation type="unfinished">&amp;Modificadores</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="150"/>
        <source>Defaults</source>
        <translation type="unfinished">Predeterminados</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="153"/>
        <source>Defaults on current tab</source>
        <translation type="unfinished">Predefinicións na lapela actual</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="230"/>
        <source>Open URL:</source>
        <translation type="unfinished">Abrir URL:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="234"/>
        <source>Auto-refresh:</source>
        <translation type="unfinished">Actualización automática:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="238"/>
        <location filename="../sources/settingsdialog.cpp" line="241"/>
        <location filename="../sources/settingsdialog.cpp" line="504"/>
        <location filename="../sources/settingsdialog.cpp" line="535"/>
        <location filename="../sources/settingsdialog.cpp" line="538"/>
        <location filename="../sources/settingsdialog.cpp" line="542"/>
        <location filename="../sources/settingsdialog.cpp" line="545"/>
        <location filename="../sources/settingsdialog.cpp" line="548"/>
        <location filename="../sources/settingsdialog.cpp" line="557"/>
        <source>Effective after restart.</source>
        <translation type="unfinished">Efectivo tras reiniciar.</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="238"/>
        <source>Track recently used:</source>
        <translation type="unfinished">Lembrar os ficheiros recentes:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="241"/>
        <source>Keep recently closed:</source>
        <translation type="unfinished">Manter os pechados recentemente:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="245"/>
        <source>Restore tabs:</source>
        <translation type="unfinished">Restaurar lapelas:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="248"/>
        <source>Restore bookmarks:</source>
        <translation type="unfinished">Restaurar marcadores:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="251"/>
        <source>Restore per-file settings:</source>
        <translation type="unfinished">Restaurar axustes por-ficheiro:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="254"/>
        <source> min</source>
        <translation type="unfinished"> min.</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="254"/>
        <location filename="../sources/settingsdialog.cpp" line="520"/>
        <source>Never</source>
        <translation type="unfinished">Nunca</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="254"/>
        <source>Save database interval:</source>
        <translation type="unfinished">Gardar o intervalo da base de datos:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="267"/>
        <source>Synchronize presentation:</source>
        <translation type="unfinished">Sincronizar a presentación:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="270"/>
        <source>Default</source>
        <translation type="unfinished">Predeterminado</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="270"/>
        <source>Presentation screen:</source>
        <translation type="unfinished">Pantalla de presentación:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="274"/>
        <source>Synchronize outline view:</source>
        <translation type="unfinished">Sincronizar a vista en esquema:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="281"/>
        <source>Zoom factor:</source>
        <translation type="unfinished">Factor de ampliación:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="285"/>
        <source> ms</source>
        <translation type="unfinished"> ms.</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="285"/>
        <source>None</source>
        <translation type="unfinished">Ningún</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="285"/>
        <source>Highlight duration:</source>
        <translation type="unfinished">Duración do resalte:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="288"/>
        <source>Highlight color:</source>
        <translation type="unfinished">Cor de resalte:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="291"/>
        <source>Annotation color:</source>
        <translation type="unfinished">Cor da anotación:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="295"/>
        <source>&apos;%1&apos; is replaced by the absolute file path. &apos;%2&apos; resp. &apos;%3&apos; is replaced by line resp. column number.</source>
        <translation type="unfinished">«%1» é substituído pola ruta absoluta ao ficheiro «%2» correspondente, «%3» é substituído pola liña correspondente ao número de columna.</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="295"/>
        <source>Source editor:</source>
        <translation type="unfinished">Editor de orixes:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="359"/>
        <source>Use tiling:</source>
        <translation type="unfinished">Usar mosaico:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="362"/>
        <source>Keep obsolete pixmaps:</source>
        <translation type="unfinished">Manter os mapas de píxeles obsoletos:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="365"/>
        <source>Use device pixel ratio:</source>
        <translation type="unfinished">Usar a taxa de píxeles do dispositivo:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="375"/>
        <source>Decorate pages:</source>
        <translation type="unfinished">Decorar páxinas:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="378"/>
        <source>Decorate links:</source>
        <translation type="unfinished">Decorar ligazóns:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="381"/>
        <source>Decorate form fields:</source>
        <translation type="unfinished">Decorar campos do formulario:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="385"/>
        <source>Background color:</source>
        <translation type="unfinished">Cor do fondo:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="388"/>
        <source>Paper color:</source>
        <translation type="unfinished">Cor do papel:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="391"/>
        <source>Presentation background color:</source>
        <translation type="unfinished">Cor do fondo da presentación:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="395"/>
        <source>Pages per row:</source>
        <translation type="unfinished">Páxinas por liña:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="399"/>
        <location filename="../sources/settingsdialog.cpp" line="402"/>
        <location filename="../sources/settingsdialog.cpp" line="406"/>
        <source> px</source>
        <translation type="unfinished"> px</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="399"/>
        <source>Page spacing:</source>
        <translation type="unfinished">Espazado de páxina:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="402"/>
        <source>Thumbnail spacing:</source>
        <translation type="unfinished">Espazado de miniaturas:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="406"/>
        <source>Thumbnail size:</source>
        <translation type="unfinished">Tamaño das miniaturas:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="406"/>
        <source>Fit to viewport</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="551"/>
        <source>Document context menu:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="554"/>
        <source>Tab context menu:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="786"/>
        <location filename="../sources/settingsdialog.cpp" line="787"/>
        <location filename="../sources/settingsdialog.cpp" line="788"/>
        <location filename="../sources/settingsdialog.cpp" line="789"/>
        <location filename="../sources/settingsdialog.cpp" line="790"/>
        <location filename="../sources/settingsdialog.cpp" line="791"/>
        <location filename="../sources/settingsdialog.cpp" line="792"/>
        <location filename="../sources/settingsdialog.cpp" line="793"/>
        <location filename="../sources/settingsdialog.cpp" line="794"/>
        <location filename="../sources/settingsdialog.cpp" line="795"/>
        <location filename="../sources/settingsdialog.cpp" line="803"/>
        <source>%1 MB</source>
        <translation type="unfinished">%1 MB</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="410"/>
        <source>Cache size:</source>
        <translation type="unfinished">Tamaño da caché:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="413"/>
        <source>Prefetch:</source>
        <translation type="unfinished">Precargar:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="416"/>
        <source>Prefetch distance:</source>
        <translation type="unfinished">Distancia de precargado:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="504"/>
        <source>Extended search dock:</source>
        <translation type="unfinished">Doca de busca ampliada:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="507"/>
        <source>Annotation overlay:</source>
        <translation type="unfinished">Anotación superposta:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="510"/>
        <source>Form field overlay:</source>
        <translation type="unfinished">Superposición dos campos do formulario:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="515"/>
        <source>Top</source>
        <translation type="unfinished">Arriba</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="515"/>
        <source>Bottom</source>
        <translation type="unfinished">Abaixo</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="515"/>
        <source>Left</source>
        <translation type="unfinished">Esquerda</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="515"/>
        <source>Right</source>
        <translation type="unfinished">Dereita</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="514"/>
        <source>Tab position:</source>
        <translation type="unfinished">Posición da lapela:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="520"/>
        <source>As needed</source>
        <translation type="unfinished">Cando se precise</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="520"/>
        <source>Always</source>
        <translation type="unfinished">Sempre</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="519"/>
        <source>Tab visibility:</source>
        <translation type="unfinished">Visibilidade da lapela:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="278"/>
        <source>Minimal scrolling:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="524"/>
        <source>Spread tabs:</source>
        <translation type="unfinished">Espallar lapelas:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="528"/>
        <source>New tab next to current tab:</source>
        <translation type="unfinished">A nova lapela despois da actual:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="531"/>
        <source>Exit after last tab:</source>
        <translation type="unfinished">Saír despois da última lapela:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="535"/>
        <source>Recently used count:</source>
        <translation type="unfinished">Nº de usados  recentemente:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="538"/>
        <source>Recently closed count:</source>
        <translation type="unfinished">Conta de pechados recentemente:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="542"/>
        <source>File tool bar:</source>
        <translation type="unfinished">Barra de ferramentas de ficheiro:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="545"/>
        <source>Edit tool bar:</source>
        <translation type="unfinished">Barra de ferramentas de edición:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="548"/>
        <source>View tool bar:</source>
        <translation type="unfinished">Barra de ferramentas de Ver:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="557"/>
        <source>Scrollable menus:</source>
        <translation type="unfinished">Menús despregábeis:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="560"/>
        <source>Searchable menus:</source>
        <translation type="unfinished">Menús que se poden buscar:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="564"/>
        <source>Toggle tool and menu bars with fullscreen:</source>
        <translation type="unfinished">Alternar barra de ferramentas e do menú en pantalla completa:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="568"/>
        <source>Use page label:</source>
        <translation type="unfinished">Usar etiqueta de páxina:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="571"/>
        <source>Document title as tab title:</source>
        <translation type="unfinished">Título do documento como título da lapela:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="575"/>
        <source>Current page in window title:</source>
        <translation type="unfinished">Páxina actual no título da xanela:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="578"/>
        <source>Instance name in window title:</source>
        <translation type="unfinished">Nome da instancia no título da xanela:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="582"/>
        <source>Highlight current thumbnail:</source>
        <translation type="unfinished">Resaltar a miniatura actual:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="585"/>
        <source>Limit thumbnails to results:</source>
        <translation type="unfinished">Mostrar só as miniaturas con resultados:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="669"/>
        <source>Zoom:</source>
        <translation type="unfinished">Ampliación:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="672"/>
        <source>Rotate:</source>
        <translation type="unfinished">Rotar:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="675"/>
        <source>Scroll:</source>
        <translation type="unfinished">Desprazamento:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="679"/>
        <source>Copy to clipboard:</source>
        <translation type="unfinished">Copiar ao portapapeis:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="682"/>
        <source>Add annotation:</source>
        <translation type="unfinished">Engadir anotación:</translation>
    </message>
    <message>
        <location filename="../sources/settingsdialog.cpp" line="685"/>
        <source>Zoom to selection:</source>
        <translation type="unfinished">Ampliar a selección:</translation>
    </message>
</context>
<context>
    <name>qpdfview::ShortcutHandler</name>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="148"/>
        <source>Action</source>
        <translation type="unfinished">Acción</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="151"/>
        <source>Key sequence</source>
        <translation type="unfinished">Secuencia de teclas</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="269"/>
        <source>Skip backward</source>
        <translation type="unfinished">Saltar cara a atrás</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="276"/>
        <source>Skip forward</source>
        <translation type="unfinished">Saltar cara a adiante</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="283"/>
        <source>Move up</source>
        <translation type="unfinished">Mover cara a arriba</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="290"/>
        <source>Move down</source>
        <translation type="unfinished">Mover cara a abaixo</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="297"/>
        <source>Move left</source>
        <translation type="unfinished">Mover cara a esquerda</translation>
    </message>
    <message>
        <location filename="../sources/shortcuthandler.cpp" line="304"/>
        <source>Move right</source>
        <translation type="unfinished">Mover cara a dereita</translation>
    </message>
</context>
<context>
    <name>qpdfview::TreeView</name>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="585"/>
        <source>&amp;Expand all</source>
        <translation type="unfinished">&amp;Expandir todo</translation>
    </message>
    <message>
        <location filename="../sources/miscellaneous.cpp" line="586"/>
        <source>&amp;Collapse all</source>
        <translation type="unfinished">&amp;Contraer todo</translation>
    </message>
</context>
</TS>
