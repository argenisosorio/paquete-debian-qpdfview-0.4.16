# Defaults for qpdfview initscript
# sourced by /etc/init.d/qpdfview
# installed at /etc/default/qpdfview by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
