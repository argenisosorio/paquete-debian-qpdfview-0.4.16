?package(qpdfview):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="qpdfview" command="/usr/bin/qpdfview"
